#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Iterator, Tuple

import spacy
from spacy.tokens import DocBin

from scripts.common.logging import get_logger

log = get_logger("prepare.build_spacy_corpus")


def iter_labeled_texts(tsv_path: Path, limit: int = 0) -> Iterator[Tuple[str, str]]:
    """
    Stream (text, label) à partir d'un TSV id/label/text.
    """
    count = 0
    with tsv_path.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        try:
            header = next(rdr)
        except StopIteration:
            log.warning("TSV vide: %s", tsv_path)
            return
        cols = [h.strip().lower() for h in header]
        try:
            label_idx = cols.index("label")
            text_idx = cols.index("text")
        except ValueError:
            raise SystemExit(f"{tsv_path} doit contenir 'label' et 'text' (header: {header})")

        for row in rdr:
            if not row or len(row) <= max(label_idx, text_idx):
                continue
            label = (row[label_idx] or "").strip()
            text = (row[text_idx] or "").strip()
            if not label or not text:
                continue
            yield text, label
            count += 1
            if limit and count >= limit:
                break


def main() -> None:
    ap = argparse.ArgumentParser(description="TSV (id/label/text) → DocBin spaCy shardé + labels.json")
    ap.add_argument("--tsv", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--labels-out", type=Path, required=True)
    ap.add_argument("--lang", type=str, default="xx")
    ap.add_argument("--shard-size", type=int, default=10000, help="0 = pas de sharding")
    ap.add_argument("--limit", type=int, default=0)
    # Compat (non utilisés, gardés pour CLI/Makefile)
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--batch-size", type=int, default=64)
    args = ap.parse_args()

    if not args.tsv.exists():
        raise SystemExit(f"TSV introuvable: {args.tsv}")

    args.out.mkdir(parents=True, exist_ok=True)
    args.labels_out.parent.mkdir(parents=True, exist_ok=True)

    nlp = spacy.blank(args.lang)
    labels_set = set()
    docs_buffer = []
    shard = 0
    total = 0
    shard_size = max(0, args.shard_size)

    for text, label in iter_labeled_texts(args.tsv, limit=args.limit):
        labels_set.add(label)
        doc = nlp.make_doc(text)
        doc.cats[label] = 1.0
        docs_buffer.append(doc)
        total += 1

        if shard_size and len(docs_buffer) >= shard_size:
            db = DocBin(store_user_data=False)
            for d in docs_buffer:
                db.add(d)
            path = args.out / f"part{shard:04d}.spacy"
            db.to_disk(path)
            log.info("Écrit %s (%d docs)", path, len(docs_buffer))
            shard += 1
            docs_buffer.clear()

    if docs_buffer:
        db = DocBin(store_user_data=False)
        for d in docs_buffer:
            db.add(d)
        path = args.out / f"part{shard:04d}.spacy"
        db.to_disk(path)
        log.info("Écrit %s (%d docs)", path, len(docs_buffer))

    labels = sorted(labels_set)
    args.labels_out.write_text(json.dumps({"labels": labels}, ensure_ascii=False, indent=2), encoding="utf-8")
    log.info("Labels (%d) → %s | Total docs: %d", len(labels), args.labels_out, total)


if __name__ == "__main__":
    main()
