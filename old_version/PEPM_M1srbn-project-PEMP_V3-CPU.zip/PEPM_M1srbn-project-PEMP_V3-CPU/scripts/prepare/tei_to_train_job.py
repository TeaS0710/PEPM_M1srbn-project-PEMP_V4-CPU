#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path

from scripts.common.logging import get_logger
from scripts.common.tei import parse, iter_docs, extract_body_text, get_modality, get_keyword

log = get_logger("prepare.tei_to_train_job")


def main():
    ap = argparse.ArgumentParser(description="TEI → TSV (id/label/text) + split train/job.")
    ap.add_argument("--corpus", type=Path, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    ap.add_argument("--label-field", type=str, required=True, help="Nom du <term type=...> à lire comme label.")
    ap.add_argument("--modality", type=str, default=None, help="Filtrer par modalité (web/asr/gold/...).")
    ap.add_argument("--train-prop", type=float, default=0.8)
    ap.add_argument("--min-chars", type=int, default=0)
    ap.add_argument("--max-tokens", type=int, default=0)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    root = parse(args.corpus).getroot()
    rows: list[tuple[str, str]] = []  # (text, label)

    for tei in iter_docs(root):
        if args.modality:
            mod = get_modality(tei)
            if (mod or "") != args.modality:
                continue

        label = get_keyword(tei, args.label_field)
        if not label:
            continue

        text = extract_body_text(tei)
        if not text:
            continue
        if args.min_chars and len(text) < args.min_chars:
            continue
        if args.max_tokens and len(text.split()) > args.max_tokens:
            continue

        rows.append((text, label))
        if args.limit and len(rows) >= args.limit:
            break

    random.seed(args.seed)
    random.shuffle(rows)
    n_train = int(len(rows) * args.train_prop)
    train, job = rows[:n_train], rows[n_train:]

    args.outdir.mkdir(parents=True, exist_ok=True)
    for name, data in (("train.tsv", train), ("job.tsv", job)):
        outp = args.outdir / name
        with outp.open("w", encoding="utf-8", newline="") as f:
            w = csv.writer(f, delimiter="\t")
            w.writerow(["id", "label", "text"])  # schéma canonique
            for i, (text, label) in enumerate(data):
                w.writerow([f"d{i}", label, text])
        log.info("Écrit %s (%d lignes)", outp, len(data))

    log.info("Total retenu: %d (train=%d / job=%d)", len(rows), len(train), len(job))


if __name__ == "__main__":
    main()
