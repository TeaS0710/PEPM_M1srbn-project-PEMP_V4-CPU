#!/usr/bin/env python3
"""
Calcule des méta-infos simples sur des TSV (ex: train/job/dev).

Actuellement:
- compte juste le nombre de lignes (instances) par fichier
  et l'écrit dans un JSON.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from scripts.common.logging import get_logger

log = get_logger("evaluate.run_meta")


def count_rows(p: Path) -> int:
    n = 0
    with p.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        next(rdr, None)  # skip header
        for _ in rdr:
            n += 1
    return n


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--files",
        nargs="+",
        required=True,
        help="Liste de TSV (train/dev/job) à compter.",
    )
    ap.add_argument(
        "--out",
        type=Path,
        required=True,
        help="Fichier JSON de sortie.",
    )
    args = ap.parse_args()

    counts = {}
    for p_str in args.files:
        p = Path(p_str)
        if not p.exists():
            log.warning("TSV introuvable, ignoré: %s", p)
            continue
        counts[p.name] = count_rows(p)

    rep = {"counts": counts}

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(
        json.dumps(rep, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    log.info("run_meta: écrit %s", args.out)


if __name__ == "__main__":
    main()
