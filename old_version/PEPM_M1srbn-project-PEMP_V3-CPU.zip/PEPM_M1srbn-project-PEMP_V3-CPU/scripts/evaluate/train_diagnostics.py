#!/usr/bin/env python3
"""
Diagnostics d'apprentissage à partir de deux rapports JSON (train et dev).

- Extrait un F1 principal dans chaque JSON (même logique que metrics_aggregate).
- Classe la situation en:
  - sous-apprentissage
  - sur-apprentissage
  - apprentissage équilibré
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict

from scripts.common.logging import get_logger

log = get_logger("evaluate.train_diagnostics")


def extract_score(j: Dict[str, Any]) -> float | None:
    """
    Même logique que metrics_aggregate, factorisée.
    """
    metrics = j.get("metrics")
    if isinstance(metrics, dict) and "eval_macro_f1" in metrics:
        return float(metrics["eval_macro_f1"])

    for key in ("score", "best_score", "cats_macro_f1"):
        if key in j:
            try:
                return float(j[key])
            except Exception:
                pass

    if "macro avg" in j:
        macro = j["macro avg"]
        if isinstance(macro, dict) and "f1-score" in macro:
            try:
                return float(macro["f1-score"])
            except Exception:
                pass

    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--train-metrics",
        type=Path,
        required=True,
        help="Rapport JSON (train).",
    )
    ap.add_argument(
        "--dev-metrics",
        type=Path,
        required=True,
        help="Rapport JSON (dev).",
    )
    ap.add_argument(
        "--out",
        type=Path,
        required=False,
        help="(Optionnel) Fichier JSON pour écrire le diagnostic.",
    )
    args = ap.parse_args()

    j_train = json.loads(args.train_metrics.read_text(encoding="utf-8"))
    j_dev = json.loads(args.dev_metrics.read_text(encoding="utf-8"))

    s_train = extract_score(j_train)
    s_dev = extract_score(j_dev)

    if s_train is None or s_dev is None:
        raise SystemExit("Impossible d'extraire un score F1 train/dev.")

    diff = s_train - s_dev

    # Heuristiques très simples (à ajuster si besoin)
    if s_train < 0.6 and s_dev < 0.6:
        status = "underfitting"
        explanation = (
            "Scores train et dev tous les deux bas (<0.6) → probable sous-apprentissage."
        )
    elif s_train >= 0.8 and diff > 0.1:
        status = "overfitting"
        explanation = (
            "Score train nettement supérieur au dev (diff > 0.1 et train >= 0.8) "
            "→ probable sur-apprentissage."
        )
    elif abs(diff) <= 0.05 and s_train >= 0.7 and s_dev >= 0.7:
        status = "balanced"
        explanation = (
            "Scores train et dev proches (|diff| <= 0.05) et >= 0.7 "
            "→ apprentissage globalement équilibré."
        )
    else:
        status = "uncertain"
        explanation = (
            "Situation intermédiaire: les scores ne rentrent pas clairement dans "
            "les cas sous-/sur-apprentissage."
        )

    diag = {
        "train_f1": s_train,
        "dev_f1": s_dev,
        "diff": diff,
        "status": status,
        "explanation": explanation,
    }

    log.info("Train F1=%.4f, Dev F1=%.4f, diff=%.4f → %s", s_train, s_dev, diff, status)
    log.info(explanation)

    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(
            json.dumps(diag, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
