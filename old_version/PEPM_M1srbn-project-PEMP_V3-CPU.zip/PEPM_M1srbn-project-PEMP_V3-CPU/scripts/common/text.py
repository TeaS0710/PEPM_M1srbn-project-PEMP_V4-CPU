#!/usr/bin/env python3
"""
Utilitaires texte génériques.
"""

from __future__ import annotations

import re


_WS_RE = re.compile(r"\s+")


def normalize_ws(s: str) -> str:
    """
    Normalise les espaces : remplace toute séquence d'espaces/blancs par un espace unique
    et strip en début/fin.
    """
    return _WS_RE.sub(" ", s or "").strip()
