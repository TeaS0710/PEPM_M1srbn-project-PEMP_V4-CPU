#!/usr/bin/env python3
"""
Utilitaires simples pour le système de fichiers.
"""

from __future__ import annotations

from pathlib import Path
import os
import shutil


def ensure_dir(p: Path | str) -> Path:
    """
    Crée le dossier si nécessaire et le retourne en Path.
    """
    path = Path(p)
    path.mkdir(parents=True, exist_ok=True)
    return path


def atomic_write(path: Path | str, data: bytes, mode: str = "wb") -> None:
    """
    Écrit `data` dans un fichier de manière atomique en passant par un fichier tmp.
    """
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, mode) as f:
        f.write(data)
    os.replace(tmp, path)


def copytree(src: Path | str, dst: Path | str, exist_ok: bool = True) -> None:
    """
    Copie récursivement un dossier `src` vers `dst`.

    Si `exist_ok=True` et que `dst` existe déjà, il est supprimé avant.
    """
    src_path, dst_path = Path(src), Path(dst)
    if dst_path.exists() and exist_ok:
        shutil.rmtree(dst_path)
    shutil.copytree(src_path, dst_path)
