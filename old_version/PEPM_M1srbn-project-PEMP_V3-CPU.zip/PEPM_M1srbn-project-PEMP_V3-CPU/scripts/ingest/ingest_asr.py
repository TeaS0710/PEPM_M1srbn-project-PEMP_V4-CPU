#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import xml.etree.ElementTree as ET

from scripts.common.logging import get_logger
from scripts.common.tei import TEI_NS, TEI, TEI_TAG, write, set_modality

log = get_logger("ingest.ingest_asr")


def find_transcript(audio_path: Path) -> str | None:
    """
    Cherche un fichier .txt de même basename que l'audio.
    Ex: foo.wav -> foo.txt
    """
    txt = audio_path.with_suffix(".txt")
    if txt.exists():
        return txt.read_text(encoding="utf-8", errors="replace").strip() or None
    return None


def main():
    ap = argparse.ArgumentParser(description="Construire un TEI à partir de transcriptions ASR (txt).")
    ap.add_argument("--in-dir", type=Path, required=True, help="Répertoire audio (wav/mp3/flac) + .txt transcrits.")
    ap.add_argument("--out-tei", type=Path, required=True, help="Fichier TEI de sortie (teiCorpus).")
    ap.add_argument("--lang", type=str, default="fr", help="Langue (info documentaire).")
    args = ap.parse_args()

    audio_exts = {".wav", ".mp3", ".flac", ".m4a", ".ogg"}
    corpus = ET.Element(f"{{{TEI_NS}}}teiCorpus")
    n, skipped = 0, 0

    for p in sorted(args.in_dir.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in audio_exts:
            continue
        text = find_transcript(p)
        if not text:
            log.warning("Aucune transcription pour %s → ignoré.", p.name)
            skipped += 1
            continue

        tei = ET.Element(TEI_TAG)
        set_modality(tei, "asr")

        # teiHeader minimal (optionnel)
        header = ET.SubElement(tei, f"{TEI}teiHeader")
        fileDesc = ET.SubElement(header, f"{TEI}fileDesc")
        titleStmt = ET.SubElement(fileDesc, f"{TEI}titleStmt")
        title = ET.SubElement(titleStmt, f"{TEI}title")
        title.text = p.stem

        # Texte
        text_el = ET.SubElement(tei, f"{TEI}text")
        body = ET.SubElement(text_el, f"{TEI}body")
        para = ET.SubElement(body, f"{TEI}p")
        para.text = text

        corpus.append(tei)
        n += 1

    write(corpus, args.out_tei)
    log.info("Écrit %s (%d TEI, %d sans transcription).", args.out_tei, n, skipped)


if __name__ == "__main__":
    main()
