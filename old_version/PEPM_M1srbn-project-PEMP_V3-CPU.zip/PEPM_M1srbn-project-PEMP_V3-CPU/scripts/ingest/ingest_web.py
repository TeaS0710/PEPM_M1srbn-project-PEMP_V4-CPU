#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import xml.etree.ElementTree as ET

from scripts.common.logging import get_logger
from scripts.common.tei import TEI_NS, TEI, TEI_TAG, NS, parse, write, iter_docs, set_modality

log = get_logger("ingest.ingest_web")


def main():
    ap = argparse.ArgumentParser(description="Tagger un corpus TEI avec une modalité (ex: web).")
    ap.add_argument("--in", dest="inp", type=Path, required=True, help="Corpus TEI d'entrée.")
    ap.add_argument("--out", dest="out", type=Path, required=True, help="Corpus TEI de sortie.")
    ap.add_argument("--value", type=str, required=True, help="Valeur de modalité (web, asr, gold, ...).")
    args = ap.parse_args()

    tree = parse(args.inp)
    root = tree.getroot()

    corpus = ET.Element(f"{{{TEI_NS}}}teiCorpus")
    n = 0
    for tei in iter_docs(root):
        set_modality(tei, args.value)
        corpus.append(tei)
        n += 1

    write(corpus, args.out)
    log.info("Écrit %s (%d TEI) [modality=%s]", args.out, n, args.value)


if __name__ == "__main__":
    main()
