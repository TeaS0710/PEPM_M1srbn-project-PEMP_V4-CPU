#!/usr/bin/env python3
from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path
import csv
import yaml

from scripts.common.logging import get_logger
from scripts.common.tei import parse, iter_docs, get_keyword, get_modality

log = get_logger("ingest.make_ideology_skeleton")


def main():
    ap = argparse.ArgumentParser(description="Extrait un squelette ideology.yml + stats acteurs.")
    ap.add_argument("--corpus", type=Path, required=True)
    ap.add_argument("--out-yaml", type=Path, required=True)
    ap.add_argument("--out-report", type=Path, required=True)
    ap.add_argument("--min-chars", type=int, default=150)
    ap.add_argument("--top-variants", type=int, default=3)
    args = ap.parse_args()

    root = parse(args.corpus).getroot()
    ideologies = Counter()
    actors = Counter()

    kept = 0
    for tei in iter_docs(root):
        text = get_keyword(tei, "title") or ""  # si tu stockes les acteurs ailleurs, adapte ici
        lab = get_keyword(tei, "ideology") or ""
        mod = get_modality(tei) or ""
        if not lab:
            continue
        if args.min_chars and len(text) < args.min_chars:
            continue
        ideologies[lab] += 1
        # compter quelques "acteurs" (ici placeholder = title)
        if text:
            actors[text] += 1
        kept += 1

    args.out_yaml.parent.mkdir(parents=True, exist_ok=True)
    args.out_report.parent.mkdir(parents=True, exist_ok=True)

    # squelette ideology.yml
    payload = {k: {} for k, _ in ideologies.most_common()}
    args.out_yaml.write_text(yaml.safe_dump(payload, allow_unicode=True, sort_keys=True), encoding="utf-8")

    # acteurs
    with args.out_report.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["actor", "count"])
        for a, c in actors.most_common():
            w.writerow([a, c])

    log.info("Écrit %s (labels=%d) et %s", args.out_yaml, len(payload), args.out_report)
    log.info("Docs retenus: %d", kept)


if __name__ == "__main__":
    main()
