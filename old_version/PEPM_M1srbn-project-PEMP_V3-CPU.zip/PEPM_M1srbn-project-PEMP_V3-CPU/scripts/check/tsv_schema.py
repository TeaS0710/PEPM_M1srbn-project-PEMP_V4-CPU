#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path

from scripts.common.logging import get_logger

log = get_logger("check.tsv_schema")


def main():
    ap = argparse.ArgumentParser(description="Vérifie le schéma TSV id/label/text.")
    ap.add_argument("--tsv", type=Path, required=True)
    ap.add_argument("--min-rows", type=int, default=1)
    args = ap.parse_args()

    if not args.tsv.exists():
        raise SystemExit(f"Introuvable: {args.tsv}")

    with args.tsv.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        try:
            header = next(rdr)
        except StopIteration:
            raise SystemExit("TSV vide.")
        cols = [h.strip().lower() for h in header]
        for need in ("id", "label", "text"):
            if need not in cols:
                raise SystemExit(f"Colonne manquante: {need} (header: {header})")
        n = sum(1 for _ in rdr)

    if n < args.min_rows:
        raise SystemExit(f"Trop peu de lignes: {n} < {args.min_rows}")

    log.info("OK: %s (header %r, rows=%d)", args.tsv, header, n)


if __name__ == "__main__":
    main()
