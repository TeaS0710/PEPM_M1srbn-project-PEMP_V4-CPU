#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from statistics import mean
from pathlib import Path

from scripts.common.logging import get_logger

log = get_logger("check.corpus_stats")


def infer_indices(tsv: Path):
    with tsv.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        try:
            header = next(rdr)
        except StopIteration:
            raise SystemExit(f"TSV vide: {tsv}")
    cols = [h.strip().lower() for h in header]
    if "text" not in cols:
        raise SystemExit(f"{tsv}: colonne 'text' manquante (header: {header})")
    return header, cols.index("text"), (cols.index("label") if "label" in cols else None)


def stats_one(tsv: Path, text_idx: int):
    lengths = []
    with tsv.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        next(rdr, None)
        for row in rdr:
            if not row or len(row) <= text_idx:
                continue
            text = (row[text_idx] or "").strip()
            if not text:
                continue
            lengths.append(len(text.split()))
    n = len(lengths)
    return {
        "n_docs": n,
        "avg_tokens": float(mean(lengths)) if lengths else 0.0,
        "min_tokens": int(min(lengths)) if lengths else 0,
        "max_tokens": int(max(lengths)) if lengths else 0,
    }


def main():
    ap = argparse.ArgumentParser(description="Stats simples sur TSV id/label/text.")
    ap.add_argument("--tsv", nargs="+", required=True)
    ap.add_argument("--out-prefix", type=str, required=True)
    args = ap.parse_args()

    tsvs = [Path(p) for p in args.tsv]
    for p in tsvs:
        if not p.exists():
            raise SystemExit(f"Introuvable: {p}")

    header, text_idx, label_idx = infer_indices(tsvs[0])

    per_file = {}
    all_lengths = []
    for p in tsvs:
        st = stats_one(p, text_idx)
        per_file[p.name] = st
        n = st["n_docs"]
        if n and st["avg_tokens"]:
            all_lengths.extend([st["avg_tokens"]] * n)

    out_json = Path(args.out_prefix + ".stats.json")
    out_json.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "per_file": per_file,
        "global": {
            "n_docs": sum(st["n_docs"] for st in per_file.values()),
            "avg_tokens": float(mean(all_lengths)) if all_lengths else 0.0,
        },
    }
    out_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    log.info("Stats → %s", out_json)

    if label_idx is not None:
        c = Counter()
        with tsvs[0].open("r", encoding="utf-8") as f:
            rdr = csv.reader(f, delimiter="\t")
            next(rdr, None)
            for row in rdr:
                if not row or len(row) <= label_idx:
                    continue
                lab = (row[label_idx] or "").strip()
                if lab:
                    c[lab] += 1
        out_lbl = Path(args.out_prefix + ".label_dist.csv")
        with out_lbl.open("w", encoding="utf-8") as g:
            g.write("label,count\n")
            for lab, cnt in c.most_common():
                g.write(f"{lab},{cnt}\n")
        log.info("Label dist → %s", out_lbl)


if __name__ == "__main__":
    main()
