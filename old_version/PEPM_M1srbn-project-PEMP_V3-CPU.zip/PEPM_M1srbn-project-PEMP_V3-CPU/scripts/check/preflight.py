#!/usr/bin/env python3
"""
Preflight TEI : vérifie qu'un corpus TEI est exploitable avant de lancer tout le pipeline.

- vérifie qu'on trouve des <TEI>,
- vérifie qu'on trouve du texte dans <text>/<body>,
- vérifie qu'on trouve des labels (crawl ou ideology),
- optionnel : filtre par modalité (web, asr, gold, web2, ...),
- optionnel : écrit un mini rapport JSON.
"""

from __future__ import annotations

import argparse
import sys
import json
from collections import Counter
from pathlib import Path

from scripts.common.logging import get_logger
from scripts.common.tei import parse, iter_docs, get_modality, get_keyword

log = get_logger("check.preflight")


def extract_text(root) -> str:
    """
    Extraction texte minimaliste à partir de <text>/<body>.
    On reste volontairement simple, indépendant du reste.
    """
    body = root.find(".//{*}text/{*}body")
    if body is None:
        return ""
    parts = []
    for el in body.iter():
        # on prend le texte des éléments de type phrase / paragraphe
        if el.text and el.tag.split("}")[-1] in {"p", "seg", "s", "l"}:
            parts.append(el.text.strip())
    return " ".join(parts)


def load_ideology_map(path: Path | None):
    if not path:
        return None
    if not path.exists():
        log.error("Missing ideology map: %s", path)
        sys.exit(4)
    import yaml
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    # normaliser en lower
    return {str(k).lower().strip(): str(v).strip() for k, v in data.items()}


def extract_label(root, field: str, ideomap: dict | None) -> str:
    """
    Lit le label depuis les <keywords>/<term> en fonction de label_field.
    """
    if field == "crawl":
        val = get_keyword(root, "crawl") or ""
        return val.strip()

    # field == ideology
    raw = (get_keyword(root, "ideology") or "").strip().lower()
    if ideomap:
        return ideomap.get(raw, "")
    return raw


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Preflight TEI: vérifie la structure et un mini pipeline texte/label."
    )
    ap.add_argument("--corpus", type=Path, required=True)
    ap.add_argument("--label-field", choices={"crawl", "ideology"}, required=True)
    ap.add_argument("--ideology-map", type=Path, required=False)
    ap.add_argument(
        "--limit",
        type=int,
        default=200,
        help="Nombre max de documents TEI à échantillonner (0 = pas de limite).",
    )
    ap.add_argument(
        "--modality",
        type=str,
        default="any",
        help="Filtre de modalité (web, asr, gold, web2, ... ou 'any' pour ne pas filtrer).",
    )
    ap.add_argument(
        "--report-json",
        type=Path,
        default=None,
        help="Optionnel: chemin d'un fichier JSON où écrire un mini rapport.",
    )
    args = ap.parse_args()

    if not args.corpus.exists():
        log.error("Missing corpus: %s", args.corpus)
        sys.exit(2)

    ideomap = None
    if args.label_field == "ideology":
        ideomap = load_ideology_map(args.ideology_map)

    root = parse(args.corpus).getroot()

    # Compteurs
    n_seen = 0
    n_with_text = 0
    n_with_label = 0
    label_counts = Counter()
    modality_counts = Counter()
    text_lengths = []

    for tei in iter_docs(root):
        if args.limit and n_seen >= args.limit:
            break
        n_seen += 1

        mod = (get_modality(tei) or "").strip().lower()
        modality_counts[mod] += 1

        if args.modality != "any" and mod != args.modality:
            continue

        text = extract_text(tei)
        if text:
            n_with_text += 1
            text_lengths.append(len(text))

        label = extract_label(tei, args.label_field, ideomap)
        if label:
            n_with_label += 1
            label_counts[label] += 1

    if n_seen == 0:
        log.error("Preflight: aucun <TEI> trouvé dans le corpus.")
        sys.exit(3)

    if n_with_text == 0:
        log.error("Preflight: aucun document avec texte non vide.")
        sys.exit(3)

    if n_with_label == 0:
        log.error(
            "Preflight: aucun document avec label non vide (label_field=%s).",
            args.label_field,
        )
        sys.exit(3)

    # Petit résumé
    summary = {
        "sampled_docs": n_seen,
        "docs_with_text": n_with_text,
        "docs_with_label": n_with_label,
        "label_field": args.label_field,
        "labels": label_counts.most_common(),
        "modalities": modality_counts.most_common(),
        "min_text_len": min(text_lengths) if text_lengths else 0,
        "max_text_len": max(text_lengths) if text_lengths else 0,
        "avg_text_len": (sum(text_lengths) / len(text_lengths))
        if text_lengths
        else 0.0,
        "modality_filter": args.modality,
    }

    log.info(
        "Preflight OK: %d docs (texte=%d, label=%d), labels=%s, modalities=%s",
        n_seen,
        n_with_text,
        n_with_label,
        dict(label_counts),
        dict(modality_counts),
    )

    if args.report_json:
        args.report_json.parent.mkdir(parents=True, exist_ok=True)
        args.report_json.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # succès
    sys.exit(0)


if __name__ == "__main__":
    main()
