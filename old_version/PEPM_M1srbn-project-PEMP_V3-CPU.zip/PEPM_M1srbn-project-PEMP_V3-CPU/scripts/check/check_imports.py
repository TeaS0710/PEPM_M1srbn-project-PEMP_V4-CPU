#!/usr/bin/env python3
"""
Vérifie que certains modules Python requis sont importables.
"""

from __future__ import annotations

import argparse
from importlib import import_module

from scripts.common.logging import get_logger

log = get_logger("check.imports")

DEFAULT_REQUIRED = ["lxml", "pandas", "psutil", "yaml", "spacy"]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--modules",
        nargs="*",
        help="Liste de modules à tester (par défaut: lxml, pandas, psutil, yaml, spacy).",
    )
    args = ap.parse_args()

    required = args.modules if args.modules else DEFAULT_REQUIRED
    ok = True
    for m in required:
        try:
            mod = import_module(m)
            log.info("OK import %s (%s)", m, getattr(mod, "__version__", "n/a"))
        except Exception as e:
            ok = False
            log.error("FAIL import %s: %s", m, e)
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
