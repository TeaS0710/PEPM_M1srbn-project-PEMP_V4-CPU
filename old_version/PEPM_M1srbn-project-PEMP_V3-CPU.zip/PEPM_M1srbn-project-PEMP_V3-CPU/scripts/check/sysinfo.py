#!/usr/bin/env python3
"""
Affiche quelques infos système utiles pour diagnostiquer l'environnement d'exécution.
"""

from __future__ import annotations

import platform
import json
import os
import shutil

from scripts.common.logging import get_logger

log = get_logger("check.sysinfo")


def main() -> None:
    info = {
        "python": platform.python_version(),
        "system": platform.platform(),
        "processor": platform.processor(),
        "env_threads": {
            k: os.environ.get(k)
            for k in [
                "OMP_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS",
            ]
        },
        "disk_total": shutil.disk_usage("/").total,
        "disk_free": shutil.disk_usage("/").free,
    }
    log.info("SYSTEM %s", json.dumps(info))
    print(json.dumps(info, ensure_ascii=False))


if __name__ == "__main__":
    main()
