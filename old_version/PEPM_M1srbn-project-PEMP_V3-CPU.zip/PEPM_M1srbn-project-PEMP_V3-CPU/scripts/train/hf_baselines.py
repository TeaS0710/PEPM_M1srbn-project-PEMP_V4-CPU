#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from scripts.common.logging import get_logger

log = get_logger("train.hf_baselines")


def load_tsv(p: Path):
    X, y = [], []
    with p.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        try:
            header = next(rdr)
        except StopIteration:
            return X, y
        cols = [h.strip().lower() for h in header]
        try:
            label_idx = cols.index("label")
            text_idx = cols.index("text")
        except ValueError:
            raise SystemExit(f"{p} doit contenir 'label' et 'text' (header: {header})")
        for row in rdr:
            if not row or len(row) <= max(label_idx, text_idx):
                continue
            lab = (row[label_idx] or "").strip()
            txt = (row[text_idx] or "").strip()
            if lab and txt:
                y.append(lab)
                X.append(txt)
    return X, y


def main():
    ap = argparse.ArgumentParser(description="HF baseline (sequence classification) sur TSV id/label/text.")
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--dev", type=Path, required=True)
    ap.add_argument("--job", type=Path, required=True)
    ap.add_argument("--models", type=str, default="camembert-base")
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--grad-accum", type=int, default=2)
    ap.add_argument("--max-len", type=int, default=256)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--use-gpu", type=int, default=0)
    ap.add_argument("--reports", type=Path, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    args = ap.parse_args()

    try:
        from transformers import (
            AutoTokenizer,
            AutoModelForSequenceClassification,
            Trainer,
            TrainingArguments,
        )
        import numpy as np
        import evaluate as hf_evaluate
        from datasets import Dataset
        import torch
    except Exception as e:
        log.error("Transformers/evaluate/datasets introuvables: %s", e)
        raise SystemExit(2)

    model_name = args.models.split(",")[0].strip()

    Xtr, ytr = load_tsv(args.train)
    Xdv, ydv = load_tsv(args.dev)
    labels = sorted(set(ytr))
    lid = {l: i for i, l in enumerate(labels)}

    tok = AutoTokenizer.from_pretrained(model_name)

    def to_ds(texts, ys):
        enc = tok(texts, truncation=True, padding=True, max_length=args.max_len)
        enc["labels"] = [lid[y] for y in ys]
        return Dataset.from_dict(enc)

    ds_tr, ds_dv = to_ds(Xtr, ytr), to_ds(Xdv, ydv)

    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=len(labels))
    metr_f1 = hf_evaluate.load("f1")
    metr_acc = hf_evaluate.load("accuracy")

    def compute_metrics(eval_pred):
        logits, labels_np = eval_pred
        preds = np.argmax(logits, axis=-1)
        return {
            "macro_f1": metr_f1.compute(predictions=preds, references=labels_np, average="macro")["f1"],
            "accuracy": metr_acc.compute(predictions=preds, references=labels_np)["accuracy"],
        }

    args.reports.mkdir(parents=True, exist_ok=True)
    args.outdir.mkdir(parents=True, exist_ok=True)

    use_gpu = bool(args.use_gpu) and torch.cuda.is_available()
    targs = TrainingArguments(
        output_dir=str(args.outdir),
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        gradient_accumulation_steps=args.grad_accum,
        num_train_epochs=args.epochs,
        learning_rate=args.lr,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        logging_steps=50,
        load_best_model_at_end=True,
        metric_for_best_model="macro_f1",
        no_cuda=not use_gpu,
    )
    trainer = Trainer(model=model, args=targs, train_dataset=ds_tr, eval_dataset=ds_dv,
                      compute_metrics=compute_metrics, tokenizer=tok)

    trainer.train()
    eval_metrics = trainer.evaluate()

    best = {
        "label_set": labels,
        "best_score": float(trainer.state.best_metric or 0.0),
        "model_name": model_name,
        "metrics": {
            "eval_macro_f1": float(eval_metrics.get("eval_macro_f1", 0.0)),
            "eval_accuracy": float(eval_metrics.get("eval_accuracy", 0.0)),
        },
    }
    (args.reports / "hf_report.json").write_text(json.dumps(best, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
