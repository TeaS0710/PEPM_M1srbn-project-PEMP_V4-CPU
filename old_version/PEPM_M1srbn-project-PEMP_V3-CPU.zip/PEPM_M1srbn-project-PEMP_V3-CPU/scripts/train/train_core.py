#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import spacy
from spacy.tokens import DocBin

from scripts.common.logging import get_logger

log = get_logger("train.train_core")


def load_docbin_dir(path: Path) -> list:
    """
    Charge tous les *.spacy d'un dossier (part0000.spacy, etc.).
    Retourne une liste de Doc (concaténée).
    """
    docs = []
    if path.is_file() and path.suffix == ".spacy":
        db = DocBin().from_disk(path)
        docs.extend(list(db.get_docs(spacy.blank("xx").vocab)))
        return docs

    for p in sorted(path.glob("*.spacy")):
        db = DocBin().from_disk(p)
        docs.extend(list(db.get_docs(spacy.blank("xx").vocab)))
    return docs


def main():
    ap = argparse.ArgumentParser(description="Entraînement spaCy textcat simple (DocBin shardé).")
    ap.add_argument("--train", type=Path, required=True, help="Dossier DocBin train (ou fichier .spacy).")
    ap.add_argument("--dev", type=Path, required=True, help="Dossier DocBin dev/job (ou fichier .spacy).")
    ap.add_argument("--out", type=Path, required=True, help="Dossier modèle de sortie.")
    ap.add_argument("--labels", type=Path, required=True, help="JSON {\"labels\": [...]}.")
    ap.add_argument("--lang", type=str, default="xx")
    ap.add_argument("--arch", type=str, default="bow", choices=["bow", "cnn"])
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--batch-start", type=int, default=16)
    ap.add_argument("--batch-stop", type=int, default=64)
    ap.add_argument("--eval-freq", type=int, default=50)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    labels = json.loads(args.labels.read_text(encoding="utf-8")).get("labels", [])
    if not labels:
        raise SystemExit(f"Aucun label dans {args.labels}")

    nlp = spacy.blank(args.lang)
    # textcat simple multi-label (mais on posera des one-hot 1.0 uniquement)
    textcat = nlp.add_pipe("textcat_multilabel", config={"exclusive_classes": True, "architecture": "simple_cnn" if args.arch == "cnn" else "bow"})
    for lab in labels:
        textcat.add_label(lab)

    # Charger DocBin → Docs (avec .cats renseigné)
    train_docs = load_docbin_dir(args.train)
    dev_docs = load_docbin_dir(args.dev)
    if not train_docs or not dev_docs:
        raise SystemExit("DocBin train/dev vides ou introuvables.")

    # Convertir en exemple spaCy
    from spacy.training import Example
    train_ex = [Example.from_dict(nlp.make_doc(d.text), {"cats": d.cats}) for d in train_docs]
    dev_ex = [Example.from_dict(nlp.make_doc(d.text), {"cats": d.cats}) for d in dev_docs]

    optimizer = nlp.initialize(lambda: train_ex)
    import random
    random.seed(args.seed)

    best_score = -1.0
    for epoch in range(args.epochs):
        random.shuffle(train_ex)
        losses = {}
        for i, batch_start in enumerate(range(0, len(train_ex), args.batch_start)):
            batch = train_ex[batch_start: batch_start + args.batch_start]
            nlp.update(batch, sgd=optimizer, losses=losses, drop=args.dropout)
            if (i + 1) % args.eval_freq == 0:
                # mini-éval intermédiaire facultative
                pass

        # Évaluation de fin d'époque
        from sklearn.metrics import f1_score, accuracy_score
        preds, refs = [], []
        for ex in dev_ex:
            doc = nlp(ex.x.text)
            # prédiction = argmax
            if not doc.cats:
                continue
            pred = max(doc.cats.items(), key=lambda kv: kv[1])[0]
            ref = max(ex.y["cats"].items(), key=lambda kv: kv[1])[0]
            preds.append(pred)
            refs.append(ref)

        if refs:
            macro_f1 = float(f1_score(refs, preds, average="macro"))
            acc = float(accuracy_score(refs, preds))
        else:
            macro_f1, acc = 0.0, 0.0

        log.info("Epoch %d: macro_f1=%.4f acc=%.4f losses=%s", epoch + 1, macro_f1, acc, losses)
        # Sauvegarde best/baseline
        model_dir = args.out / ("model-best" if macro_f1 > best_score else "model-last")
        if macro_f1 > best_score:
            best_score = macro_f1
            nlp.to_disk(model_dir)
        else:
            nlp.to_disk(model_dir)

    # écrire un mini meta
    (args.out / "meta.json").write_text(
        json.dumps({"labels": labels, "best_macro_f1": best_score}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    log.info("Terminé. Best macro_f1=%.4f", best_score)


if __name__ == "__main__":
    main()
